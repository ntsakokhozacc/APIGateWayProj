using ReportApi.Configuration;

namespace ReportApi.Modals.DTO.Request
{
    public class RegistrationResponse : AuthResult
    {
        
    }
}